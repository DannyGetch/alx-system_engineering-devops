Shell Variables and Expansions
